# -*- coding: utf-8 -*-
"""
Created on Thu May  1 18:57:47 2025

@author: maria
"""
#CRIAR TABELA

import mysql.connector

def conectar_banco():
    return mysql.connector.connect(
        host='svc-3482219c-a389-4079-b18b-d50662524e8a-shared-dml.aws-virginia-6.svc.singlestore.com',
        port='3333',
        user='ARTECJAM',
        password='u)eKirme27uyE8xFxp=id',
        database='db_mariana_676af'
    )

def criar_tabela():
    try:
        conn = conectar_banco()
        cursor = conn.cursor()

        # SQL query to create the table
        create_table_query = """
        CREATE TABLE dadosDummySHIFT (
            id INT AUTO_INCREMENT PRIMARY KEY,
            hora TIME,
            data DATE,
            sujeira INT,
            eficiencia INT
        );
        """

        # Execute the query to create the table
        cursor.execute(create_table_query)

        # Commit the changes
        conn.commit()

        print("📝 Tabela 'dadosDummySHIFT' criada com sucesso!")

        # Close the connection
        cursor.close()
        conn.close()

    except mysql.connector.Error as err:
        print(f"Erro ao criar a tabela: {err}")

# Call the function to create the table
criar_tabela()
