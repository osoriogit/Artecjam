# -*- coding: utf-8 -*-
"""
Created on Thu May  1 19:31:32 2025

@author: maria
"""

import mysql.connector
import random
from datetime import datetime, timedelta

def conectar_banco():
    return mysql.connector.connect(
        host='svc-3482219c-a389-4079-b18b-d50662524e8a-shared-dml.aws-virginia-6.svc.singlestore.com',
        port='3333',
        user='ARTECJAM',
        password='u)eKirme27uyE8xFxp=id',
        database='db_mariana_676af'
    )

def gerar_dados_dummy(qtd=20):
    base_date = datetime.today()
    dados = []
    for i in range(qtd):
        hora = (datetime.min + timedelta(minutes=random.randint(300, 1200))).time()  # random time between 5:00 and 20:00
        data = (base_date - timedelta(days=random.randint(0, 10))).date()  # random date within the last 10 days
        sujeira = random.randint(0, 100)
        eficiencia = 100-sujeira
        dados.append((hora, data, sujeira, eficiencia))
    return dados

def inserir_dados(dados):
    try:
        conn = conectar_banco()
        cursor = conn.cursor()

        query = """
        INSERT INTO dadosDummySHIFT (hora, data, sujeira, eficiencia)
        VALUES (%s, %s, %s, %s)
        """

        cursor.executemany(query, dados)
        conn.commit()

        print(f"✅ {cursor.rowcount} registros inseridos com sucesso na tabela 'dadosDummySHIFT'.")

        cursor.close()
        conn.close()

    except mysql.connector.Error as err:
        print(f"Erro ao inserir dados: {err}")

# Gerar e inserir 20 entradas dummy
dados = gerar_dados_dummy(1)
inserir_dados(dados)
