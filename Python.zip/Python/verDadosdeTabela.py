# -*- coding: utf-8 -*-
"""
Created on Thu May  1 18:52:51 2025

@author: maria
"""
#VER O QUE ESTÀ NA TABELA

import mysql.connector

def conectar_banco():
    return mysql.connector.connect(
        host='svc-3482219c-a389-4079-b18b-d50662524e8a-shared-dml.aws-virginia-6.svc.singlestore.com',
        port='3333',
        user='ARTECJAM',
        password='u)eKirme27uyE8xFxp=id',
        database='db_mariana_676af'
    )

def buscar_dados():
    try:
        conn = conectar_banco()
        cursor = conn.cursor()

        # Execute a SELECT query to fetch data
        query = "SELECT * FROM dadosDummySHIFT LIMIT 20;"  # Change the query as needed
        cursor.execute(query)

        # Fetch all rows from the result of the query
        resultados = cursor.fetchall()

        # Print the fetched data
        print("📋 Dados da tabela 'dadosDummySHIFT':")
        for row in resultados:
            print(row)

        cursor.close()
        conn.close()

    except mysql.connector.Error as err:
        print(f"Erro ao buscar dados: {err}")

# Call the function to fetch and display the data
buscar_dados()
