# -*- coding: utf-8 -*-
"""
Created on Thu May  1 18:59:15 2025

@author: maria
"""

#VER QUE TABELAS ESTÂO
#MUDAR O NOME DA TABELA

import mysql.connector

def conectar_banco():
    return mysql.connector.connect(
        host='svc-3482219c-a389-4079-b18b-d50662524e8a-shared-dml.aws-virginia-6.svc.singlestore.com',
        port='3333',
        user='ARTECJAM',
        password='u)eKirme27uyE8xFxp=id',
        database='db_mariana_676af'
    )

def verificar_colunas():
    try:
        conn = conectar_banco()
        cursor = conn.cursor()
        
        # Query to get column names from the table
        cursor.execute("SHOW COLUMNS FROM testSHIFT;")
        colunas = cursor.fetchall()
        
        print("📋 Colunas da tabela 'testSHIFT':")
        for coluna in colunas:
            print(f"- {coluna[0]}")  # Print each column name

        cursor.close()
        conn.close()
        
    except mysql.connector.Error as err:
        print(f"Erro ao acessar o banco de dados: {err}")

# Chama a função para verificar as colunas
verificar_colunas()
