# -*- coding: utf-8 -*-
"""
Created on Thu May  1 19:00:23 2025

@author: maria
"""

#VER TABELAS QUE EXISTEM
import mysql.connector

try:
    conn = mysql.connector.connect(
        host='svc-3482219c-a389-4079-b18b-d50662524e8a-shared-dml.aws-virginia-6.svc.singlestore.com',
        port='3333',
        user='ARTECJAM',
        password='u)eKirme27uyE8xFxp=id',
        database='db_mariana_676af'
    )
    cursor = conn.cursor()
    cursor.execute("SHOW TABLES;")
    tabelas = cursor.fetchall()

    print("📋 Tabelas disponíveis:")
    for tabela in tabelas:
        print("-", tabela[0])

    cursor.close()
    conn.close()
except mysql.connector.Error as err:
    print(f"Erro ao acessar banco de dados: {err}")
